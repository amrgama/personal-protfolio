import Fade from "./fade.js";
import Popup from "./popup.js";
import Whirlpool from "./whirlpool.js";